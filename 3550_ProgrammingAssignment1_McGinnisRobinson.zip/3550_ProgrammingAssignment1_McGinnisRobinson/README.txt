#README
#Name: Daniel McGinnis, Riley Robinson
#Class: EECS3550:001 Software Engineering
#Project: Programming Assignment 1 Jaz to C++ Translator
#03/22/2018
#Description: This program takes programs written in the Jaz
# machine instruction set as input and converts them to the equivalent
# C++ code.
#Status: The program is not 100% functional. Please review this
# documentation for a complete explanation.

Please install Python 3.0 or higher to run this code.

These instructions are not functioning properly:
Control Flow
label l
goto l
gofalse l
gotrue l

When Executed the following files will generate error free C++ code:
operatorsTest.jaz

However, due to the missing instructions the following files only produce some or most of the the appropriate C++ source code and prints it to a file �JazCPP.cpp�.
foo.jaz
factProc.jaz
demo.jaz
recFact.jaz


